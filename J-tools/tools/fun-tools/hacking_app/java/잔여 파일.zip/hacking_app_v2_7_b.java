import javax.swing.*;
import javax.swing.text.DefaultCaret;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

public class hacking_app_v2_7_b extends JFrame {
    private JTextArea textArea;
    private JProgressBar progressBar;
    private JButton startButton, stopButton, clearButton;
    private volatile boolean running = false;

    private File logFile;

    public hacking_app_v2_7_b() {
        VersionInfo verInfo = loadVersionInfo();
        setTitle(verInfo.windowTitle);
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // 검정 배경 + 진한 초록 글씨
        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setBackground(Color.BLACK);
        textArea.setForeground(Color.GREEN);
        textArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
        // 자동 스크롤 (예비)
        DefaultCaret caret = (DefaultCaret) textArea.getCaret();
        caret.setUpdatePolicy(DefaultCaret.NEVER_UPDATE); // 기존 ALWAYS_UPDATE 대신 NEVER_UPDATE로 둠 (수동으로 처리)

        add(new JScrollPane(textArea), BorderLayout.CENTER);

        progressBar = new JProgressBar(0, 100);
        add(progressBar, BorderLayout.NORTH);

        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(Color.BLACK);

        startButton = new JButton("Start Hacking");
        startButton.setBackground(Color.GREEN);
        startButton.setForeground(Color.BLACK);

        stopButton = new JButton("Stop");
        stopButton.setBackground(Color.RED);
        stopButton.setForeground(Color.WHITE);

        clearButton = new JButton("Clear (CLS)");
        clearButton.setBackground(Color.GRAY);
        clearButton.setForeground(Color.WHITE);

        btnPanel.add(startButton);
        btnPanel.add(stopButton);
        btnPanel.add(clearButton);

        add(btnPanel, BorderLayout.SOUTH);

        startButton.addActionListener(e -> startHacking());
        stopButton.addActionListener(e -> stopHacking());
        clearButton.addActionListener(e -> clearText());

        setupLogFile(verInfo.version, verInfo.isBeta);
    }

    private VersionInfo loadVersionInfo() {
        String version = "v?.?";
        boolean isBeta = false;
        String windowTitle = "Hacking_app_" + version;

        File verFile = new File("versions/version.txt");
        if (verFile.exists()) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(verFile), StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) {
                    if (line.startsWith("version=")) {
                        version = line.split("=", 2)[1].trim();
                    } else if (line.startsWith("beta_version=")) {
                        isBeta = line.split("=", 2)[1].trim().equalsIgnoreCase("true");
                    }
                }
            } catch (IOException e) {
                showError("version.txt 읽기 실패: " + e.getMessage());
            }
        } else {
            showError("version.txt 파일이 없습니다!");
        }
        windowTitle = isBeta ? "Hacking_app_" + version + "[beta]" : "Hacking_app_" + version;
        return new VersionInfo(windowTitle, version, isBeta);
    }

    private void setupLogFile(String version, boolean isBeta) {
        try {
            File logDir = new File("LOGS");
            if (!logDir.exists()) logDir.mkdirs();

            String today = new SimpleDateFormat("yyyyMMdd").format(new Date());
            String fileName = version + "_" + today + ".log";
            logFile = new File(logDir, fileName);

            if (!logFile.exists()) {
                try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(logFile), StandardCharsets.UTF_8))) {
                    writer.write("[INFO] App version: " + version + ", beta: " + isBeta + "\n");
                }
            }
        } catch (IOException e) {
            showError("로그 파일 생성 중 오류: " + e.getMessage());
        }
    }

    private void startHacking() {
        if (running) return;
        running = true;
        setTitle("Hacking...");
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        progressBar.setValue(0);

        new Thread(() -> {
            try {
                simulateLoading();
                generateFakeProgress();
                runFakeMessages();
            } catch (InterruptedException ignored) {
            } finally {
                running = false;
                VersionInfo verInfo = loadVersionInfo();
                SwingUtilities.invokeLater(() -> {
                    setTitle(verInfo.windowTitle);
                    setCursor(Cursor.getDefaultCursor());
                    progressBar.setValue(0);
                });
            }
        }).start();
    }

    private void stopHacking() {
        running = false;
        appendText("[SYSTEM] Hacking stopping...");
        setTitle("Stopping...");
        setCursor(Cursor.getDefaultCursor());
        progressBar.setValue(0);
    }

    private void clearText() {
        textArea.setText("");
    }

    private void simulateLoading() throws InterruptedException {
        String[] loadingTexts = {"[.] Loading modules", "[..] Initializing network", "[...] Connecting..."};
        for (int i = 0; i < 3; i++) {
            if (!running) return;
            appendText(loadingTexts[i]);
            Thread.sleep(800);
        }
    }

    private void generateFakeProgress() throws InterruptedException {
        Random rand = new Random();
        for (int i = 0; i <= 100; i++) {
            if (!running) return;
            final int val = i;
            SwingUtilities.invokeLater(() -> progressBar.setValue(val));
            Thread.sleep(20 + rand.nextInt(10));
        }
    }

    private void runFakeMessages() throws InterruptedException {
        Random rand = new Random();

        List<String> baseMessages = new ArrayList<>();
        baseMessages.add("[*] Target found at " + randomIP());
        baseMessages.add("[*] Scanning open ports...");
        baseMessages.add("[+] Port " + rand.nextInt(65535) + " open");
        baseMessages.add("[*] Brute forcing password...");
        baseMessages.add("[+] Password found: " + randomPassword());
        baseMessages.add("[*] Accessing system...");
        baseMessages.add("[+] Downloading files...");
        baseMessages.add("[*] Uploading malware...");
        baseMessages.add("[+] Operation complete.");
        baseMessages.add("[!] Connection lost.");
        baseMessages.add("[*] Reestablishing connection...");
        baseMessages.add("[+] Connected to secure shell");
        baseMessages.add("[!] Firewall bypassed");
        baseMessages.add("[+] Admin panel compromised");
        baseMessages.add("[*] Exfiltrating data...");
        baseMessages.add("[!] Backdoor installed successfully.");

        List<String> customMessages = new ArrayList<>();
        customMessages.add("[!] D-DOS Confirmed.");
        customMessages.add("[+] D-DOS Complete.");
        customMessages.add("[!] ERR 404 Target " + randomIP() + " is No Found.");
        customMessages.add("[!] Port " + rand.nextInt(65535) + " (HTTP) close.");
        customMessages.add("[!] Port " + rand.nextInt(65535) + " (SSH) close");
        customMessages.add("[+] Port " + rand.nextInt(65535) + " (HTTP) open");
        customMessages.add("[+] Port " + rand.nextInt(65535) + " (SSH) open");
        customMessages.add("[!] Attack Failed: Attack Type: D-DOS Error Format: Defended");
        customMessages.add("[!] Attack Failed: Attack Type: Worm computer virus program(aaa.exe) Error Format: Defended(deleted File)");

        while (running) {
            String message = rand.nextBoolean()
                    ? baseMessages.get(rand.nextInt(baseMessages.size()))
                    : customMessages.get(rand.nextInt(customMessages.size()));
            String timestamp = new SimpleDateFormat("[HH:mm:ss] ").format(new Date());
            String fullMessage = timestamp + message;
            appendText(fullMessage);

            if (message.toLowerCase().contains("backdoor")) {
                showPopup("⚠️ Backdoor detected!");
            } else if (rand.nextDouble() < 0.1) {
                showPopup(randomPopupMessage());
            }

            Thread.sleep(300 + rand.nextInt(700));
        }
    }

    private void appendText(String text) {
        SwingUtilities.invokeLater(() -> {
            textArea.append(text + "\n");
            // **자동 스크롤 처리**
            textArea.setCaretPosition(textArea.getDocument().getLength());
        });
        writeLog(text);
    }

    private void writeLog(String text) {
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(logFile, true), StandardCharsets.UTF_8))) {
            writer.write(text + "\n");
        } catch (IOException e) {
            // 무시
        }
    }

    private String randomIP() {
        Random r = new Random();
        return String.format("%d.%d.%d.%d", r.nextInt(246)+10, r.nextInt(256), r.nextInt(256), r.nextInt(253)+1);
    }

    private String randomPassword() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        Random rnd = new Random();
        StringBuilder sb = new StringBuilder(8);
        for (int i=0; i<8; i++) {
            sb.append(chars.charAt(rnd.nextInt(chars.length())));
        }
        return sb.toString();
    }

    private String randomPopupMessage() {
        String[] msgs = {
            "⚠️ D-DOS 공격 감지됨!",
            "❌ 시스템 방화벽 활성화됨.",
            "🛑 접속 실패: 인증 오류",
            "🚫 악성코드 삭제됨",
            "💣 치명적 오류 발생. 로그 기록 중..."
        };
        return msgs[new Random().nextInt(msgs.length)];
    }

    private void showPopup(String message) {
        SwingUtilities.invokeLater(() -> {
            JDialog dialog = new JDialog(this, "WARNING");
            dialog.setUndecorated(true);
            dialog.setAlwaysOnTop(true);
            dialog.getContentPane().setBackground(Color.YELLOW);

            JLabel label = new JLabel(message, SwingConstants.CENTER);
            label.setFont(new Font("Arial", Font.BOLD, 14));
            label.setForeground(Color.RED);
            label.setOpaque(true);
            label.setBackground(Color.YELLOW);
            dialog.add(label);

            dialog.setSize(300, 100);

            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Random rnd = new Random();
            int x = rnd.nextInt(screenSize.width - 300);
            int y = rnd.nextInt(screenSize.height - 100);

            dialog.setLocation(x, y);
            dialog.setVisible(true);

            // 3초 후 자동 닫기
            new java.util.Timer().schedule(new java.util.TimerTask() {
                @Override
                public void run() {
                    dialog.dispose();
                }
            }, 3000);
        });
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "오류", JOptionPane.ERROR_MESSAGE);
    }

    private static class VersionInfo {
        String windowTitle;
        String version;
        boolean isBeta;

        VersionInfo(String windowTitle, String version, boolean isBeta) {
            this.windowTitle = windowTitle;
            this.version = version;
            this.isBeta = isBeta;
        }
    }

    public static void main(String[] args) {
        System.setProperty("file.encoding", "UTF-8");

        SwingUtilities.invokeLater(() -> {
            hacking_app_v2_7_b app = new hacking_app_v2_7_b();
            app.setVisible(true);
        });
    }
}
